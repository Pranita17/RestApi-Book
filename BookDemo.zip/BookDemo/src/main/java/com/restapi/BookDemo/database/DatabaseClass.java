package com.restapi.BookDemo.database;

import java.util.HashMap;
import java.util.Map;

import com.restapi.BookDemo.model.Book;

public class DatabaseClass {

	private static Map<Long, Book> books = new HashMap<>();
	//private static Map<Long, Author> authors = new HashMap<>();
	
	public static Map<Long, Book> getBook() {
		return books;
	}
	
//	public static Map<Long, Author> getAuthor() {
//		return authors;
//	}
}
