package com.restapi.BookDemo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.restapi.BookDemo.database.DatabaseClass;
import com.restapi.BookDemo.model.Book;

public class BookService {
	
	private static Map<Long, Book> books = DatabaseClass.getBook();
	
	public BookService()
	{
		books.put(1L,new Book(1,"The Alchemist","Pranita"));
		books.put(2L,new Book(2,"The Blue Umbrella","Pranita"));
	}
	
	public List<Book> getAllBooks()
	{
//		Book a1=new Book(1, "The Alchemist", "Pranita");
//		Book a2=new Book(2, "The Blue Umbrella","Pranita");
//		Book a3=new Book(3, "The Brahmin", "Pranita");
//
//		List<Book> list=new ArrayList<Book>();
//		list.add(a1);
//		list.add(a2);
//		list.add(a3);
//		
//		return list;
		return new ArrayList<Book>(books.values());
	}
	
	public Book getBook(long id) {
		return books.get(id);
	}
	
	public static Book addBook(Book book) {
		book.setId(books.size()+1);
		books.put(book.getId(),book);
		return book;
	}
	
	public static Book updateBook(Book book) {
		if(book.getId() <= 0) {
			return null;	
		}
		books.put(book.getId(), book);
		return book;
		
	}
	
	public static Book removeBook(long id) {
		return books.remove(id);
	}
}
