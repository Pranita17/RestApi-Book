package com.restapi.BookDemo.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.restapi.BookDemo.model.Book;
import com.restapi.BookDemo.service.BookService;

@Path("/books")
public class BookResource {

BookService bookService= new BookService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)	
	public List<Book> getBook() {
	System.out.println("called");
	return bookService.getAllBooks();
	}
	
	@GET
	@Path("/{bookId}")
	@Produces(MediaType.APPLICATION_XML)
	public Book getBook(@PathParam("bookId") long id) {
		return bookService.getBook(id);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Book addBook(Book book) {
		return BookService.addBook(book);
	}
	
	@PUT
	@Path("/{bookId}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Book updateBook(@PathParam("bookId") long id,Book book) {
		book.setId(id);
		return BookService.updateBook(book);
	}
	
	@DELETE
	@Path("/{bookId}")
	@Produces(MediaType.APPLICATION_XML)
	public Book deleteBook(@PathParam("bookId") long id) {
		return BookService.removeBook(id);
	}
	
	@GET
	@Path("{bookId}/author")
	public String test() {
		return "test";
	}
}
