package com.restapi.BookDemo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.restapi.BookDemo.database.DatabaseClass;
import com.restapi.BookDemo.model.Author;
import com.restapi.BookDemo.model.Book;

public class AuthorService {

	private static Map<Long, Book> books = DatabaseClass.getBook();
	
	public List<Author> getAllAuthor(long bookId){
		Map<Long, Author> author = books.get(bookId).getAuthor();
		return new ArrayList<Author>(author.values());
	}
	
	public Author getAuthor(long bookId, long authorId) {
		Map<Long, Author> author = books.get(bookId).getAuthor();
		return author.get(authorId);
	}

//	public Author addAuthor(long bookId, Author author) {
//		Map<Long, Author> author = books.get(bookId).getAuthor();
//		author.setId(author.size() + 1);
//		author.put(author.getId, author);
//	}
//	
//	public Author updateAuthor(long bookId, Author author) {
//		Map<Long, Author> author = books.get(bookId).getAuthor();
//		if (author.getId() <= 0) {
//			return null;
//		}
//		author.put(author.getId, author);
//		return author;
//	}
//	
//	public Author deleteAuthor(long bookId, long authorId) {
//		Map<Long, Author> author = books.get(bookId).getAuthor();
//		return author.remove(authorId);
//	}
}
