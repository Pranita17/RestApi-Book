package com.restapi.BookDemo.resources;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.restapi.BookDemo.model.Author;
import com.restapi.BookDemo.model.Book;
import com.restapi.BookDemo.service.AuthorService;
import com.restapi.BookDemo.service.BookService;

@Path("/")
public class AuthorResource {

	private AuthorService authorService= new AuthorService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)	
	public List<Author> getAllAuthor(@PathParam("bookId")long bookId) {
	return authorService.getAllAuthor(bookId);
	}
	
//	@POST
//	@Produces(MediaType.APPLICATION_XML)
//	public Author addBook(@PathParam("bookId")long bookId, Author author) {
//	return authorService.addAuthor(bookId, author);
//	}
//	
//	@PUT
//	@Path("/{authorId}")
//	@Produces(MediaType.APPLICATION_XML)
//	public Author updateBook(@PathParam("bookId")long bookId, @PathParam("authorId")long id, Author author){
//	author.setId(id);
//	return authorService.updateAuthor(bookId, author);
//	}
//	
//	@DELETE
//	@Path("/{authorId}")
//	@Produces(MediaType.APPLICATION_XML)
//	public void deleteBook(@PathParam("bookId")long bookId, @PathParam("authorId")long authorId){
//		authorService.deleteAuthor(bookId, authorId);
//	}
//	@GET
//	@Path("/{authorId}")
//	@Produces(MediaType.APPLICATION_XML)	
//	public Author getAuthor(@PathParam("bookId")long bookId, @PathParam("authorId") long authorId ) {
//	return authorService.getAuthor(bookId, authorId);
//}
}
