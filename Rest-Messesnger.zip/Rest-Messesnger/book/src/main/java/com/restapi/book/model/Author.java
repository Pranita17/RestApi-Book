package com.restapi.book.model;

public class Author {

}
