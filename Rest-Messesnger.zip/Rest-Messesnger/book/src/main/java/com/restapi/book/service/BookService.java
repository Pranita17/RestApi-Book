package com.restapi.book.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.restapi.book.database.DatabaseClass;
import com.restapi.book.model.Book;

public class BookService {

private static Map<Long, Book> books = DatabaseClass.getBook();

public BookService()
{
	books.put(1L,new Book(1,"Hello World","ABC"));
	books.put(2L,new Book(2,"Hello Jersey","XYZ"));
}

	public List<Book> getAllBooks(){
		return new ArrayList<Book>(books.values());
	}
	
	public static Book getBook(long id) {
		return books.get(id);
	}
	
	public static Book addBook(Book book) {
		book.setId(books.size()+1);
		books.put(book.getId(),book);
		return book;
	}
	
	public static Book updateBook(Book book) {
		if(book.getId() <= 0) {
			return null;	
		}
		books.put(book.getId(), book);
		return book;
		
	}
	
	public static Book removeBook(long id) {
		return books.remove(id);
	}
}
