package com.restapi.book.database;

import java.util.HashMap;
import java.util.Map;

import com.restapi.book.model.Author;
import com.restapi.book.model.Book;

public class DatabaseClass {

	private static Map<Long, Book> books = new HashMap<>();
	private static Map<Long, Author> authors = new HashMap<>();
	
	public static Map<Long, Book> getBook() {
		return books;
	}
	
	public static Map<Long, Author> getAuthor() {
		return authors;
	}
}
